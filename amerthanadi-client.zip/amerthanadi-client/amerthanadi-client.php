<?php
/**
 * Plugin Name: Amerthanadi Studios - Client Connector
 * Description: Monitoring dashboard informasi masa aktif, status perpanjangan, dan widget dinamis.
 * Version: 5.2
 * Author: Amerthanadi Studios
 * Author URI: https://www.amerthanadi.com
 */

if (!defined('ABSPATH')) exit;

// Fungsi ambil data dengan cache 10 menit
function as_get_client_payload() {
    $payload = get_transient('as_full_payload_v52');
    if (false === $payload) {
        $api_url = 'https://amerthanadi.com/wp-json/amerthanadi/v2/data/';
        $response = wp_remote_get($api_url, ['timeout' => 20]);
        if (is_wp_error($response)) return false;
        
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        set_transient('as_full_payload_v52', $payload, 600); 
    }
    return $payload;
}

// 1. Banner Masa Aktif (Tampilan 2 Kolom)
add_action('admin_notices', 'as_show_expiry_banner_v50');
function as_show_expiry_banner_v50() {
    $data = as_get_client_payload();
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    
    if (!$data || !isset($data['clients'][$current_domain])) return;
    $client = $data['clients'][$current_domain];
    if (empty($client['expiry'])) return;

    // Logika Label & Style Status
    $status_text = "BELUM DIPERPANJANG";
    $status_style = "color: #ffd700; animation: as_blink 1.2s infinite;";
    
    if (isset($client['status'])) {
        if ($client['status'] === 'success') {
            $status_text = "TELAH DIPERPANJANG";
            $status_style = "color: #00ff00; font-weight: bold;";
        } elseif ($client['status'] === 'expired') {
            $status_text = "JATUH TEMPO";
            $status_style = "color: #ff4444; font-weight: bold;";
        }
    }
    ?>
    <style>
        .as-gold-banner { 
            background: #1a1a1a !important; color: #ffffff !important; padding: 25px; 
            margin: 20px 20px 10px 2px; border-radius: 12px; border: 2px solid #ffd700; 
            box-shadow: 0 4px 25px rgba(0,0,0,0.5); display: flex; flex-wrap: wrap; 
            gap: 30px; align-items: stretch; box-sizing: border-box; max-width: 98%; 
        }
        .as-col-info { flex: 1; min-width: 280px; }
        .as-col-info h2 { 
            color: #ffd700 !important; margin: 0 0 15px 0 !important; font-weight: 900 !important; 
            text-transform: uppercase; font-size: 22px; line-height: 1.2;
        }
        .as-detail-row { margin-bottom: 8px; font-size: 15px; line-height: 1.4; }
        .as-yellow { color: #ffd700; font-weight: bold; }
        
        .as-btn-pay {
            display: inline-block; background: #ffd700; color: #000 !important; 
            padding: 12px 25px; text-decoration: none; font-weight: 900; 
            border-radius: 8px; margin-top: 15px; transition: 0.3s ease;
            text-align: center; text-transform: uppercase; border: none; cursor: pointer;
        }
        .as-btn-pay:hover { background: #008000 !important; color: #ffffff !important; }

        .as-col-msg { 
            flex: 1.2; min-width: 280px; padding: 20px; border: 1px solid rgba(255,215,0,0.3); 
            border-radius: 10px; background: rgba(255,255,255,0.05);
        }
        .as-col-msg::before {
            content: "PESAN NOTIFIKASI:"; display: block; color: #ffd700; 
            font-weight: 900; font-size: 12px; margin-bottom: 10px;
        }

        @keyframes as_blink { 50% { opacity: 0.3; } }
        @media screen and (max-width: 782px) {
            .as-gold-banner { padding: 15px; gap: 20px; }
            .as-btn-pay { width: 100%; box-sizing: border-box; }
        }
    </style>

    <div class="as-gold-banner">
        <div class="as-col-info">
            <h2>MASA AKTIF: <?php echo esc_html($client['expiry']); ?></h2>
            <div class="as-detail-row">Biaya Perpanjangan: <span class="as-yellow"><?php echo esc_html($client['cost']); ?></span></div>
            <div class="as-detail-row">Tanggal Dibayar: <span class="as-yellow"><?php echo esc_html($client['paid_date'] ?: '-'); ?></span></div>
            <div class="as-detail-row">Status: <span style="<?php echo $status_style; ?>"><?php echo $status_text; ?></span></div>
            
            <a href="https://amerthanadi.com/pembayaran/" target="_blank" class="as-btn-pay">BAYAR SEKARANG / REKENING</a>
        </div>

        <div class="as-col-msg">
            <div style="font-size: 14px; line-height: 1.6; color: #eee;">
                <?php echo !empty($client['message']) ? wp_kses_post($client['message']) : "Silakan bayar setiap tanggal " . esc_html($client['expiry']) . " tahun berikutnya."; ?>
            </div>
        </div>
    </div>
    <?php
}

// 2. Registrasi Widget Dashboard
add_action('wp_dashboard_setup', function() {
    wp_add_dashboard_widget('as_widget_profile', '🆔 PROFIL DEVELOPER', 'as_render_profile_widget');
    wp_add_dashboard_widget('as_widget_updates', '🚀 UPDATE & INFORMASI', 'as_render_combined_updates_widget');
});

// Style Khusus Dashboard
add_action('admin_head', function() {
    ?>
    <style>
        /* Widget Profil */
        .as-profile-card { background: #1a1a1a; color: #fff; padding: 20px; border-radius: 8px; }
        .as-status-row { color: #fff; font-size: 14px; margin-bottom: 15px; font-weight: bold; }
        .as-status-val { font-size: 16px; text-transform: uppercase; }
        .as-blink-red { color: #ff4444; animation: as_blink 1s infinite; font-weight: 900; }
        .as-val-success { color: #ffd700; font-weight: 900; }
        .as-co-name { font-size: 24px; font-weight: 900; color: #ffd700; margin-bottom: 10px; text-transform: uppercase; display: block; }
        .as-co-detail { font-size: 13px; color: #ccc; margin-bottom: 5px; line-height: 1.5; }
        .as-btn-wa { display: block; background: #ff0000; color: #fff !important; text-align: center; padding: 12px; border-radius: 5px; text-decoration: none; font-weight: bold; margin-top: 15px; text-transform: uppercase; }
        
        /* Widget Gabungan Artikel */
        .as-section-title { font-weight: 900; border-bottom: 2px solid #ffd700; padding-bottom: 5px; margin: 15px 0 10px 0; font-size: 14px; color: #00008b; }
        .as-list-article { padding-left: 20px; margin: 0; }
        .as-list-article li { margin-bottom: 5px; font-weight: bold; color: #00008b; list-style-type: decimal; }
        .as-list-article a { text-decoration: none; color: #00008b; }
        .as-list-article a:hover { color: #ffd700; }
        .as-btn-more { display: inline-block; font-size: 11px; font-weight: bold; color: #ffd700 !important; background: #00008b; padding: 3px 10px; border-radius: 3px; text-decoration: none; margin-top: 5px; text-transform: uppercase; }
    </style>
    <?php
});

// Render Widget Profil
function as_render_profile_widget() {
    $data = as_get_client_payload();
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    $client = $data['clients'][$current_domain] ?? null;
    $profile = $data['profile'] ?? [];

    $status_html = '<span class="as-blink-red">BELUM DIPERPANJANG</span>';
    if (($client['status'] ?? '') === 'success') {
        $status_html = '<span class="as-val-success">TELAH DIPERPANJANG</span>';
    } elseif (($client['status'] ?? '') === 'expired') {
        $status_html = '<span class="as-blink-red">JATUH TEMPO</span>';
    }
    
    $wa_link = "https://wa.me/" . preg_replace('/[^0-9]/', '', ($profile['phone'] ?? ''));
    ?>
    <div class="as-profile-card">
        <div class="as-status-row">STATUS : <?php echo $status_html; ?></div>
        <span class="as-co-name"><?php echo esc_html($profile['name'] ?? 'AMERTHANADI STUDIOS'); ?></span>
        <div class="as-co-detail">📍 <?php echo esc_html($profile['address'] ?? '-'); ?></div>
        <div class="as-co-detail">📞 <?php echo esc_html($profile['phone'] ?? '-'); ?></div>
        <div class="as-co-detail">📧 <?php echo esc_html($profile['email'] ?? '-'); ?></div>
        <a href="<?php echo esc_url($wa_link); ?>" target="_blank" class="as-btn-wa">HUBUNGI DEVELOPER</a>
    </div>
    <?php
}

// Render Widget Gabungan (News, KB, Services)
function as_render_combined_updates_widget() {
    $data = as_get_client_payload();
    
    $sections = [
        ['title' => '📰 NEWS UPDATE', 'key' => 'news', 'link' => 'https://amerthanadi.com/blog/', 'btn' => 'Lihat Artikel'],
        ['title' => '💡 PANDUAN & TIPS', 'key' => 'kb', 'link' => 'https://amerthanadi.com/kb/', 'btn' => 'Lihat Panduan Lainnya'],
        ['title' => '🛠️ LAYANAN KAMI', 'key' => 'services', 'link' => 'https://amerthanadi.com/jasa/', 'btn' => 'Lihat Layanan Lainnya']
    ];

    foreach ($sections as $sec) {
        echo '<div class="as-section-title">' . $sec['title'] . '</div>';
        $posts = $data[$sec['key']] ?? [];
        if (empty($posts)) {
            echo "<p style='font-size:12px; color:#999;'>Tidak ada data tersedia.</p>";
        } else {
            echo '<ol class="as-list-article">';
            foreach (array_slice($posts, 0, 5) as $p) {
                echo '<li><a href="'.esc_url($p['link']).'" target="_blank">'.esc_html($p['title']).'</a></li>';
            }
            echo '</ol>';
        }
        echo '<a href="'.esc_url($sec['link']).'" target="_blank" class="as-btn-more">'.$sec['btn'].'</a>';
    }
}

/** SISTEM UPDATE OTOMATIS GITHUB **/
add_filter('site_transient_update_plugins', 'as_check_update_v52');
function as_check_update_v52($transient) {
    if (empty($transient->checked)) return $transient;
    $remote_url = 'https://raw.githubusercontent.com/amerthanadistudios/klienupdate.json/main/klienupdate.json';
    $response = wp_remote_get($remote_url, ['timeout' => 15]);
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
        $remote_info = json_decode(wp_remote_retrieve_body($response));
        if ($remote_info && version_compare('5.2', $remote_info->version, '<')) {
            $obj = new stdClass();
            $obj->slug = 'amerthanadi-client/amerthanadi-client.php';
            $obj->new_version = $remote_info->version;
            $obj->package = $remote_info->download_url;
            $obj->url = 'https://github.com/amerthanadistudios/klienupdate.json';
            $transient->response[$obj->slug] = $obj;
        }
    }
    return $transient;
}