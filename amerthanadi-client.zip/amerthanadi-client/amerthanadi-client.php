<?php
/**
 * Plugin Name: Amerthanadi Studios - Client Connector
 * Description: Monitoring dashboard dengan UI Dark Mode & Gold Edition.
 * Version: 4.1
 * Author: Amerthanadi Studios
 * Author URI: https://www.amerthanadi.com
 */

if (!defined('ABSPATH')) exit;

// Fungsi ambil data dengan cache 10 menit
function as_get_client_payload() {
    $payload = get_transient('as_full_payload_v41');
    if (false === $payload) {
        $api_url = 'https://amerthanadi.com/wp-json/amerthanadi/v2/data/';
        $response = wp_remote_get($api_url, ['timeout' => 20]);
        if (is_wp_error($response)) return false;
        
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        set_transient('as_full_payload_v41', $payload, 600); 
    }
    return $payload;
}

// 1. Banner Masa Aktif (Dark Mode & Gold Text)
add_action('admin_notices', 'as_show_expiry_banner_v41');
function as_show_expiry_banner_v41() {
    $data = as_get_client_payload();
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    
    if (!$data || !isset($data['clients'][$current_domain])) return;
    $client = $data['clients'][$current_domain];
    if (empty($client['expiry'])) return;

    ?>
    <style>
        .as-gold-banner { 
            background: #1a1a1a !important; /* Dark Mode Background */
            color: #ffd700 !important; /* Gold Text */
            padding: 25px; 
            margin: 20px 20px 10px 0; 
            border-radius: 8px; 
            border: 2px solid #ffd700; 
            box-shadow: 0 4px 20px rgba(255,215,0,0.2);
        }
        .as-gold-banner h2 { 
            color: #ffd700 !important; 
            margin: 0; 
            font-weight: 900; 
            text-transform: uppercase;
            font-size: 24px;
        }
        .as-gold-btn {
            display: inline-block; 
            background: #ffd700; 
            color: #000 !important; 
            padding: 10px 25px; 
            text-decoration: none; 
            font-weight: bold; 
            border-radius: 50px; 
            margin-top: 15px;
            transition: 0.3s;
        }
        .as-gold-btn:hover { background: #fff; }
    </style>
    <div class="as-gold-banner">
        <h2>⚠️ MASA AKTIF: <?php echo esc_html($client['expiry']); ?></h2>
        <p style="margin: 10px 0; font-size: 16px;">Silakan lakukan perpanjangan layanan tepat waktu.</p>
        <a href="https://amerthanadi.com/pembayaran/" target="_blank" class="as-gold-btn">PEMBAYARAN & REKENING</a>
    </div>
    <?php
}

// 2. Widget Dashboard (Dark Mode & Gold Profile)
add_action('wp_dashboard_setup', function() {
    wp_add_dashboard_widget('as_info_widget_v41', '🛡️ Amerthanadi Studios - Gold Edition', 'as_dashboard_render_v41');
});

function as_dashboard_render_v41() {
    $data = as_get_client_payload();
    if (!$data) { echo "Koneksi terputus."; return; }

    $profile = $data['profile'];
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    $client = isset($data['clients'][$current_domain]) ? $data['clients'][$current_domain] : null;

    ?>
    <style>
        .as-dark-card { 
            background: #1a1a1a; 
            padding: 20px; 
            border-radius: 10px; 
            color: #fff; 
            text-align: center;
            border: 1px solid #333;
        }
        .as-dark-card h1 { 
            color: #ffd700 !important; 
            font-weight: 900 !important; 
            font-size: 22px !important; 
            margin-bottom: 5px !important;
            text-transform: uppercase;
        }
        .as-dark-card p { color: #ccc; font-size: 13px; line-height: 1.5; }
        .as-gold-box { 
            background: rgba(255,215,0,0.1); 
            border: 1px solid #ffd700; 
            padding: 15px; 
            margin: 15px 0; 
            border-radius: 5px; 
            color: #ffd700;
        }
    </style>

    <div class="as-dark-card">
        <h1><?php echo esc_html($profile['name']); ?></h1>
        <p>📍 <?php echo esc_html($profile['address']); ?></p>
        <p>📞 <?php echo esc_html($profile['phone']); ?> | 📧 <?php echo esc_html($profile['email']); ?></p>

        <?php if($client): ?>
        <div class="as-gold-box">
            <small>STATUS WEBSITE</small><br>
            <strong style="font-size: 18px;"><?php echo esc_html($client['expiry']); ?></strong>
        </div>
        <?php endif; ?>

        <a href="https://amerthanadi.com/pembayaran/" target="_blank" class="button button-primary" style="background:#ffd700; color:#000; border:none; font-weight:bold; width:100%;">HUBUNGI DEVELOPER</a>
    </div>
    <?php
}

/**
 * SISTEM UPDATE OTOMATIS GITHUB
 */
add_filter('site_transient_update_plugins', 'as_check_update_v41');
function as_check_update_v41($transient) {
    if (empty($transient->checked)) return $transient;

    // GANTI DENGAN LINK RAW GITHUB ANDA
    $remote_url = 'https://raw.githubusercontent.com/amerthanadistudios/klienupdate.json/main/klienupdate.json';
    $response = wp_remote_get($remote_url, ['timeout' => 15]);

    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
        $remote_info = json_decode(wp_remote_retrieve_body($response));
        $current_version = '4.0'; // Versi yang lama (supaya terdeteksi perlu update)

        if ($remote_info && version_compare($current_version, $remote_info->version, '<')) {
            $obj = new stdClass();
            $obj->slug = 'amerthanadi-client';
            $obj->new_version = $remote_info->version;
            $obj->package = $remote_info->download_url;
            $transient->response[$obj->slug] = $obj;
        }
    }
    return $transient;
}