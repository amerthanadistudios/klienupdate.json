<?php
/**
 * Plugin Name: Amerthanadi Studios - Client Connector
 * Description: Dashboard monitoring terintegrasi pembayaran Amerthanadi Studios.
 * Version: 3.0
 * Author: Amerthanadi Studios
 */

if (!defined('ABSPATH')) exit;

function as_get_client_payload() {
    $payload = get_transient('as_full_payload_v3');
    if (false === $payload) {
        $api_url = 'https://amerthanadi.com/wp-json/amerthanadi/v2/data/';
        $response = wp_remote_get($api_url, ['timeout' => 20]);
        if (is_wp_error($response)) return false;
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        set_transient('as_full_payload_v3', $payload, 600); 
    }
    return $payload;
}

// Banner Atas
add_action('admin_notices', 'as_show_expiry_banner_v3');
function as_show_expiry_banner_v3() {
    $data = as_get_client_payload();
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    
    if (!$data || !isset($data['clients'][$current_domain])) return;
    $client = $data['clients'][$current_domain];

    ?>
    <div style="background:#d63638; color:#fff; padding:25px; margin:20px 20px 10px 0; border-radius:4px; border-left:10px solid #000;">
        <h2 style="color:#fff; margin:0;">⚠️ MASA AKTIF WEBSITE: <?php echo esc_html($client['expiry']); ?></h2>
        <?php if($client['cost']): ?>
            <p style="font-size:18px; margin:10px 0;">Biaya Perpanjangan: <strong><?php echo esc_html($client['cost']); ?></strong></p>
        <?php endif; ?>
        <a href="https://amerthanadi.com/pembayaran/" target="_blank" style="display:inline-block; background:#fff; color:#d63638; padding:10px 20px; text-decoration:none; font-weight:bold; border-radius:4px; margin-top:10px;">BAYAR SEKARANG / CEK REKENING</a>
        <?php if($client['message']) echo '<div style="background:#fff; color:#000; padding:15px; margin-top:15px; border-radius:4px; border-left:5px solid #ffb900; font-style:italic;">"' . nl2br(esc_html($client['message'])) . '"</div>'; ?>
    </div>
    <?php
}

// Widget Dashboard
add_action('wp_dashboard_setup', function() {
    wp_add_dashboard_widget('as_info_widget', '🛡️ Amerthanadi Studios Support', 'as_dashboard_widget_render_v3');
});

function as_dashboard_widget_render_v3() {
    $data = as_get_client_payload();
    if (!$data) { echo "Gagal terhubung ke Server."; return; }

    $profile = $data['profile'];
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    $client = isset($data['clients'][$current_domain]) ? $data['clients'][$current_domain] : null;

    ?>
    <div style="background:#f1f1f1; padding:15px; border-radius:5px; border:1px solid #ccc;">
        <h3 style="margin:0; color:#d63638;"><?php echo esc_html($profile['name']); ?></h3>
        <p style="font-size:12px;">📍 <?php echo esc_html($profile['address']); ?><br>📞 <?php echo esc_html($profile['phone']); ?> | 📧 <?php echo esc_html($profile['email']); ?></p>
    </div>

    <?php if($client): ?>
    <div style="background:#fff; border:2px solid #d63638; padding:15px; margin:15px 0; border-radius:5px; text-align:center;">
        STATUS: <strong><?php echo esc_html($client['expiry']); ?></strong><br>
        BIAYA: <strong><?php echo esc_html($client['cost'] ?: '-'); ?></strong><br><br>
        <a href="https://amerthanadi.com/pembayaran/" target="_blank" class="button button-primary" style="background:#d63638; width:100%;">INFO PEMBAYARAN & REKENING</a>
    </div>
    <?php endif; ?>

    <h4>Update Studio:</h4>
    <ul style="padding-left:15px; font-size:13px;">
        <?php foreach($data['posts'] as $post): ?>
            <li><a href="<?php echo esc_url($post['link']); ?>" target="_blank"><?php echo esc_html($post['title']); ?></a></li>
        <?php endforeach; ?>
    </ul>
    <?php
}

/**
 * SISTEM UPDATE OTOMATIS VIA GITHUB
 */
add_filter('site_transient_update_plugins', 'as_check_github_update');

function as_check_github_update($transient) {
    if (empty($transient->checked)) return $transient;

    // GUNAKAN LINK RAW GITHUB ANDA DI SINI
    $remote_url = 'https://raw.githubusercontent.com/username/repo-name/main/klienupdate.json';
    
    $response = wp_remote_get($remote_url, array('timeout' => 15));

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) return $transient;

    $remote_info = json_decode(wp_remote_retrieve_body($response));
    
    // Versi plugin saat ini (Pastikan ini naik saat Anda rilis update)
    $current_version = '4.0'; 

    if ($remote_info && version_compare($current_version, $remote_info->version, '<')) {
        $obj = new stdClass();
        $obj->slug = $remote_info->slug;
        $obj->new_version = $remote_info->version;
        $obj->url = 'https://github.com/username/repo-name'; // Link repo Anda
        $obj->package = $remote_info->download_url; // Link download ZIP tadi
        
        $transient->response[$remote_info->slug] = $obj;
    }

    return $transient;
}