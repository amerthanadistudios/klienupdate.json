<?php
/**
 * Plugin Name: Amerthanadi Studios - Client Connector
 * Description: Monitoring dashboard informasi masa aktif, status perpanjangan, dan widget dinamis.
 * Version: 5.1
 * Author: Amerthanadi Studios
 * Author URI: https://www.amerthanadi.com
 */

if (!defined('ABSPATH')) exit;

// Fungsi ambil data dengan cache 10 menit
function as_get_client_payload() {
    // Gunakan suffix versi pada transient agar data fresh saat update plugin
    $payload = get_transient('as_full_payload_v51');
    if (false === $payload) {
        $api_url = 'https://amerthanadi.com/wp-json/amerthanadi/v2/data/';
        $response = wp_remote_get($api_url, ['timeout' => 20]);
        if (is_wp_error($response)) return false;
        
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        set_transient('as_full_payload_v51', $payload, 600); 
    }
    return $payload;
}

// 1. Banner Masa Aktif (Tampilan 2 Kolom)
add_action('admin_notices', 'as_show_expiry_banner_v50');
function as_show_expiry_banner_v50() {
    $data = as_get_client_payload();
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    
    if (!$data || !isset($data['clients'][$current_domain])) return;
    $client = $data['clients'][$current_domain];
    if (empty($client['expiry'])) return;

    // Logika Label & Style Status
    $status_text = "BELUM DIPERPANJANG";
    $status_style = "color: #ffd700; animation: as_blink 1.2s infinite;";
    
    if (isset($client['status'])) {
        if ($client['status'] === 'success') {
            $status_text = "TELAH DIPERPANJANG";
            $status_style = "color: #00ff00; font-weight: bold;";
        } elseif ($client['status'] === 'expired') {
            $status_text = "JATUH TEMPO";
            $status_style = "color: #ff4444; font-weight: bold;";
        }
    }
    ?>
    <style>
        .as-gold-banner { 
            background: #1a1a1a !important; color: #ffffff !important; padding: 25px; 
            margin: 20px 20px 10px 2px; border-radius: 12px; border: 2px solid #ffd700; 
            box-shadow: 0 4px 25px rgba(0,0,0,0.5); display: flex; flex-wrap: wrap; 
            gap: 30px; align-items: stretch; box-sizing: border-box; max-width: 98%; 
        }
        .as-col-info { flex: 1; min-width: 280px; }
        .as-col-info h2 { 
            color: #ffd700 !important; margin: 0 0 15px 0 !important; font-weight: 900 !important; 
            text-transform: uppercase; font-size: 22px; line-height: 1.2;
        }
        .as-detail-row { margin-bottom: 8px; font-size: 15px; line-height: 1.4; }
        .as-yellow { color: #ffd700; font-weight: bold; }
        
        .as-btn-pay {
            display: inline-block; background: #ffd700; color: #000 !important; 
            padding: 12px 25px; text-decoration: none; font-weight: 900; 
            border-radius: 8px; margin-top: 15px; transition: 0.3s ease;
            text-align: center; text-transform: uppercase; border: none; cursor: pointer;
        }
        .as-btn-pay:hover { background: #008000 !important; color: #ffffff !important; }

        .as-col-msg { 
            flex: 1.2; min-width: 280px; padding: 20px; border: 1px solid rgba(255,215,0,0.3); 
            border-radius: 10px; background: rgba(255,255,255,0.05);
        }
        .as-col-msg::before {
            content: "PESAN NOTIFIKASI:"; display: block; color: #ffd700; 
            font-weight: 900; font-size: 12px; margin-bottom: 10px;
        }

        @keyframes as_blink { 50% { opacity: 0.3; } }
        @media screen and (max-width: 782px) {
            .as-gold-banner { padding: 15px; gap: 20px; }
            .as-btn-pay { width: 100%; box-sizing: border-box; }
        }
    </style>

    <div class="as-gold-banner">
        <div class="as-col-info">
            <h2>MASA AKTIF: <?php echo esc_html($client['expiry']); ?></h2>
            <div class="as-detail-row">Biaya Perpanjangan: <span class="as-yellow"><?php echo esc_html($client['cost']); ?></span></div>
            <div class="as-detail-row">Tanggal Dibayar: <span class="as-yellow"><?php echo esc_html($client['paid_date'] ?: '-'); ?></span></div>
            <div class="as-detail-row">Status: <span style="<?php echo $status_style; ?>"><?php echo $status_text; ?></span></div>
            
            <a href="https://amerthanadi.com/pembayaran/" target="_blank" class="as-btn-pay">BAYAR SEKARANG / REKENING</a>
        </div>

        <div class="as-col-msg">
            <div style="font-size: 14px; line-height: 1.6; color: #eee;">
                <?php echo !empty($client['message']) ? wp_kses_post($client['message']) : "Silakan bayar setiap tanggal " . esc_html($client['expiry']) . " tahun berikutnya."; ?>
            </div>
        </div>
    </div>
    <?php
}

// 2. Tiga Widget Dashboard Otomatis
add_action('wp_dashboard_setup', function() {
    wp_add_dashboard_widget('as_widget_news', '📰 NEWS UPDATE', 'as_render_news_widget');
    wp_add_dashboard_widget('as_widget_kb', '💡 PANDUAN & TIPS', 'as_render_kb_widget');
    wp_add_dashboard_widget('as_widget_services', '🛠️ LAYANAN KAMI', 'as_render_services_widget');
});

function as_dashboard_widget_styles() {
    ?>
    <style>
        .as-widget-container { background: #ffffff; padding: 5px; color: #333; }
        .as-widget-list { padding-left: 20px; margin: 10px 0; }
        .as-widget-list li { 
            margin-bottom: 8px; 
            color: #00008b; 
            font-weight: 700; 
            list-style-type: decimal; 
        }
        .as-widget-list li a { text-decoration: none; color: #00008b; }
        .as-widget-list li a:hover { color: #ffd700; }
        
        .as-btn-widget { 
            display: block; 
            text-align: center; 
            background: #ffd700; 
            color: #000 !important; 
            padding: 10px; 
            border-radius: 4px; 
            text-decoration: none; 
            font-weight: bold; 
            font-size: 13px; 
            margin-top: 15px;
            text-transform: uppercase;
        }
        .as-btn-widget:hover { background: #00008b !important; color: #fff !important; }
    </style>
    <?php
}
add_action('admin_head', 'as_dashboard_widget_styles');

// Render Widget 1: NEWS UPDATE
function as_render_news_widget() {
    $data = as_get_client_payload();
    $posts = $data['news'] ?? [];
    echo '<div class="as-widget-container">';
    if (empty($posts)) {
        echo "<p>Tidak ada berita terbaru.</p>";
    } else {
        echo '<ol class="as-widget-list">';
        foreach(array_slice($posts, 0, 10) as $p) {
            echo '<li><a href="'.esc_url($p['link']).'" target="_blank">'.esc_html($p['title']).'</a></li>';
        }
        echo '</ol>';
    }
    echo '<a href="https://amerthanadi.com/blog/" target="_blank" class="as-btn-widget">Lihat Artikel</a>';
    echo '</div>';
}

// Render Widget 2: PANDUAN & TIPS
function as_render_kb_widget() {
    $data = as_get_client_payload();
    $posts = $data['kb'] ?? [];
    echo '<div class="as-widget-container">';
    if (empty($posts)) {
        echo "<p>Panduan belum tersedia.</p>";
    } else {
        echo '<ol class="as-widget-list">';
        foreach(array_slice($posts, 0, 10) as $p) {
            echo '<li><a href="'.esc_url($p['link']).'" target="_blank">'.esc_html($p['title']).'</a></li>';
        }
        echo '</ol>';
    }
    echo '<a href="https://amerthanadi.com/kb/" target="_blank" class="as-btn-widget">Lihat Panduan Lainnya</a>';
    echo '</div>';
}

// Render Widget 3: LAYANAN KAMI
function as_render_services_widget() {
    $data = as_get_client_payload();
    $posts = $data['services'] ?? [];
    echo '<div class="as-widget-container">';
    if (empty($posts)) {
        echo "<p>Layanan belum tersedia.</p>";
    } else {
        echo '<ol class="as-widget-list">';
        foreach(array_slice($posts, 0, 10) as $p) {
            echo '<li><a href="'.esc_url($p['link']).'" target="_blank">'.esc_html($p['title']).'</a></li>';
        }
        echo '</ol>';
    }
    echo '<a href="https://amerthanadi.com/jasa/" target="_blank" class="as-btn-widget">Lihat Layanan Lainnya</a>';
    echo '</div>';
}

/** SISTEM UPDATE OTOMATIS GITHUB **/
add_filter('site_transient_update_plugins', 'as_check_update_v51');
function as_check_update_v51($transient) {
    if (empty($transient->checked)) return $transient;
    $remote_url = 'https://raw.githubusercontent.com/amerthanadistudios/klienupdate.json/main/klienupdate.json';
    $response = wp_remote_get($remote_url, ['timeout' => 15]);
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
        $remote_info = json_decode(wp_remote_retrieve_body($response));
        $current_version = '5.1'; // Ganti menjadi Versi Terbaru
        if ($remote_info && version_compare($current_version, $remote_info->version, '<')) {
            $obj = new stdClass();
            $obj->slug = 'amerthanadi-client/amerthanadi-client.php';
            $obj->new_version = $remote_info->version;
            $obj->package = $remote_info->download_url;
            $obj->url = 'https://github.com/amerthanadistudios/klienupdate.json';
            $transient->response[$obj->slug] = $obj;
        }
    }
    return $transient;
}