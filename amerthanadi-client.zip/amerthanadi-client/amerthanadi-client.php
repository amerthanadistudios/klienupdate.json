<?php
/**
 * Plugin Name: Amerthanadi Studios - Client Connector
 * Description: Monitoring dashboard dengan UI Gold Edition & Feed Artikel Terintegrasi.
 * Version: 4.9
 * Author: Amerthanadi Studios
 * Author URI: https://www.amerthanadi.com
 */

if (!defined('ABSPATH')) exit;

// Fungsi ambil data dengan cache 10 menit
function as_get_client_payload() {
    $payload = get_transient('as_full_payload_v42');
    if (false === $payload) {
        $api_url = 'https://amerthanadi.com/wp-json/amerthanadi/v2/data/';
        $response = wp_remote_get($api_url, ['timeout' => 20]);
        if (is_wp_error($response)) return false;
        
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        set_transient('as_full_payload_v42', $payload, 600); 
    }
    return $payload;
}

// 1. Banner Masa Aktif (Tampilan Baru 2 Kolom)
add_action('admin_notices', 'as_show_expiry_banner_v42');
function as_show_expiry_banner_v42() {
    $data = as_get_client_payload();
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    
    if (!$data || !isset($data['clients'][$current_domain])) return;
    $client = $data['clients'][$current_domain];
    if (empty($client['expiry'])) return;

    // Logika Label & Style Status
    $status_text = "BELUM DIPERPANJANG";
    $status_style = "color: #ffd700; animation: as_blink 1.2s infinite;";
    
    if (isset($client['status'])) {
        if ($client['status'] === 'success') {
            $status_text = "TELAH DIPERPANJANG";
            $status_style = "color: #00ff00; font-weight: bold;";
        } elseif ($client['status'] === 'expired') {
            $status_text = "JATUH TEMPO";
            $status_style = "color: #ff4444; font-weight: bold;";
        }
    }
    ?>
    <style>
        .as-gold-banner { 
            background: #1a1a1a !important; color: #ffffff !important; padding: 25px; 
            margin: 20px 20px 10px 2px; border-radius: 12px; border: 2px solid #ffd700; 
            box-shadow: 0 4px 25px rgba(0,0,0,0.5); display: flex; flex-wrap: wrap; 
            gap: 30px; align-items: stretch; box-sizing: border-box; max-width: 98%; 
        }
        .as-col-info { flex: 1; min-width: 300px; }
        .as-col-info h2 { 
            color: #ffd700 !important; margin: 0 0 15px 0 !important; font-weight: 900 !important; 
            text-transform: uppercase; font-size: 24px; line-height: 1.2;
        }
        .as-detail-row { margin-bottom: 8px; font-size: 15px; line-height: 1.4; }
        .as-yellow { color: #ffd700; font-weight: bold; }
        
        .as-btn-pay {
            display: inline-block; background: #ffd700; color: #000 !important; 
            padding: 14px 30px; text-decoration: none; font-weight: 900; 
            border-radius: 8px; margin-top: 15px; transition: 0.3s ease;
            text-align: center; text-transform: uppercase; border: none; cursor: pointer;
        }
        .as-btn-pay:hover { background: #008000 !important; color: #ffffff !important; }

        .as-col-msg { 
            flex: 1.2; min-width: 300px; padding: 20px; border: 1px solid rgba(255,215,0,0.3); 
            border-radius: 10px; background: rgba(255,255,255,0.05); position: relative;
        }
        .as-col-msg::before {
            content: "PESAN NOTIFIKASI:"; display: block; color: #ffd700; 
            font-weight: 900; font-size: 12px; margin-bottom: 10px; letter-spacing: 1px;
        }

        @keyframes as_blink { 50% { opacity: 0.3; } }

        @media screen and (max-width: 782px) {
            .as-gold-banner { padding: 20px; gap: 20px; }
            .as-btn-pay { width: 100%; box-sizing: border-box; }
        }
    </style>

    <div class="as-gold-banner">
        <div class="as-col-info">
            <h2>MASA AKTIF</h2>
            <div class="as-detail-row">Tanggal Aktif: <span class="as-yellow"><?php echo esc_html($client['expiry']); ?></span></div>
            <div class="as-detail-row">Biaya Perpanjangan: <span><?php echo esc_html($client['cost']); ?></span></div>
            <div class="as-detail-row">Tanggal Dibayar: <span class="as-yellow"><?php echo esc_html($client['paid_date'] ?: '-'); ?></span></div>
            <div class="as-detail-row">Status: <span style="<?php echo $status_style; ?>"><?php echo $status_text; ?></span></div>
            
            <a href="https://amerthanadi.com/pembayaran/" target="_blank" class="as-btn-pay">BAYAR SEKARANG!</a>
        </div>

        <div class="as-col-msg">
            <div style="font-size: 14px; line-height: 1.6; color: #eee;">
                <?php echo !empty($client['message']) ? wp_kses_post($client['message']) : "Silakan lakukan pembayaran tepat waktu untuk menghindari pemutusan layanan."; ?>
            </div>
        </div>
    </div>
    <?php
}

// 2. Widget Dashboard (Tetap dipertahankan dengan UI Gold)
add_action('wp_dashboard_setup', function() {
    wp_add_dashboard_widget('as_info_widget_v42', '🛡️ Amerthanadi Studios Support', 'as_dashboard_render_v42');
});

function as_dashboard_render_v42() {
    $data = as_get_client_payload();
    if (!$data) { echo "Koneksi ke server Amerthanadi terputus."; return; }

    $profile = $data['profile'];
    $current_domain = str_replace('www.', '', strtolower(parse_url(get_site_url(), PHP_URL_HOST)));
    $client = isset($data['clients'][$current_domain]) ? $data['clients'][$current_domain] : null;
    ?>
    <style>
        .as-dark-section { background: #1a1a1a; padding: 20px; border-radius: 10px 10px 0 0; color: #fff; text-align: center; border: 1px solid #333; }
        .as-dark-section h1 { color: #ffd700 !important; font-weight: 900 !important; font-size: 20px !important; text-transform: uppercase; margin-bottom: 5px !important; }
        .as-gold-box { background: rgba(255,215,0,0.1); border: 1px solid #ffd700; padding: 10px; margin: 15px 0; border-radius: 5px; color: #ffd700; font-weight: bold; }
        .as-light-section { background: #ffffff; padding: 20px; border-radius: 0 0 10px 10px; border: 1px solid #ddd; border-top: none; color: #333; }
        .as-light-section h4 { color: #000; font-weight: 800; border-bottom: 2px solid #eee; padding-bottom: 10px; margin-top: 0; }
        .as-article-list { padding-left: 20px; margin: 15px 0; }
        .as-article-list li { margin-bottom: 10px; color: #00008b; font-weight: 700; list-style-type: decimal; }
        .as-article-list a { text-decoration: none; color: #00008b; }
        .as-footer-btns { display: flex; gap: 10px; margin-top: 20px; }
        .as-footer-btns a { flex: 1; text-align: center; padding: 8px; text-decoration: none; font-weight: bold; border-radius: 4px; font-size: 12px; }
        .btn-blog { background: #f0f0f0; color: #333; border: 1px solid #ccc; }
        .btn-jasa { background: #00008b; color: #fff; border: none; }
    </style>

    <div class="as-dark-section">
        <h1><?php echo esc_html($profile['name']); ?></h1>
        <p style="font-size:11px; color:#ccc;"><?php echo esc_html($profile['address']); ?></p>
        <?php if($client): ?>
        <div class="as-gold-box">STATUS: <?php echo esc_html($client['expiry']); ?></div>
        <?php endif; ?>
        <a href="https://amerthanadi.com/pembayaran/" target="_blank" class="button button-primary" style="background:#ffd700; color:#000; border:none; font-weight:bold; width:100%; height:36px; line-height:34px; display:block;">HUBUNGI DEVELOPER</a>
    </div>

    <div class="as-light-section">
        <h4>Amerthanadi Studio Update</h4>
        <ol class="as-article-list">
            <?php foreach($data['posts'] as $post): ?>
                <li><a href="<?php echo esc_url($post['link']); ?>" target="_blank"><?php echo esc_html($post['title']); ?></a></li>
            <?php endforeach; ?>
        </ol>
        <div class="as-footer-btns">
            <a href="https://amerthanadi.com/blog" target="_blank" class="btn-blog">Artikel lainnya</a>
            <a href="https://amerthanadi.com/jasa/" target="_blank" class="btn-jasa">Layanan Kami</a>
        </div>
    </div>
    <?php
}

/** SISTEM UPDATE OTOMATIS GITHUB **/
add_filter('site_transient_update_plugins', 'as_check_update_v47');
function as_check_update_v47($transient) {
    if (empty($transient->checked)) return $transient;
    $remote_url = 'https://raw.githubusercontent.com/amerthanadistudios/klienupdate.json/main/klienupdate.json';
    $response = wp_remote_get($remote_url, ['timeout' => 15]);
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200) {
        $remote_info = json_decode(wp_remote_retrieve_body($response));
        $current_version = '4.9'; // Versi Terbaru
        if ($remote_info && version_compare($current_version, $remote_info->version, '<')) {
            $obj = new stdClass();
            $obj->slug = 'amerthanadi-client/amerthanadi-client.php';
            $obj->new_version = $remote_info->version;
            $obj->package = $remote_info->download_url;
            $obj->url = 'https://github.com/amerthanadistudios/klienupdate.json';
            $transient->response[$obj->slug] = $obj;
        }
    }
    return $transient;
}